class ImpedanceSquaredMixin(object):

    quantity = 'impedancesquared'
    quantity_label = 'Impedance^2'
    quantity_units = 'ohm^2'
    is_impedancesquared = True
    is_squared = True
